from mavic2pro_simpleactions import * 
init(5001)
