from mavic2pro_simpleactions2 import * 
init(5003)
